<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'ti', 'li', 'bin', 'zong', 'di', 'peng', 'song', 'zheng', 'quan', 'zong', 'shun', 'jian', 'tuo', 'hu', 'la', 'jiu',
  0x10 => 'qi', 'lian', 'zhen', 'bin', 'peng', 'ma', 'san', 'man', 'man', 'seng', 'xu', 'lie', 'qian', 'qian', 'nang', 'huan',
  0x20 => 'kuo', 'ning', 'bin', 'lie', 'rang', 'dou', 'dou', 'nao', 'hong', 'xi', 'dou', 'han', 'dou', 'dou', 'jiu', 'chang',
  0x30 => 'yu', 'yu', 'ge', 'yan', 'fu', 'qin', 'gui', 'zong', 'liu', 'gui', 'shang', 'yu', 'gui', 'mei', 'ji', 'qi',
  0x40 => 'ga', 'kui', 'hun', 'ba', 'po', 'mei', 'xu', 'yan', 'xiao', 'liang', 'yu', 'tui', 'qi', 'wang', 'liang', 'wei',
  0x50 => 'gan', 'chi', 'piao', 'bi', 'mo', 'ji', 'xu', 'chou', 'yan', 'zhan', 'yu', 'dao', 'ren', 'jie', 'ba', 'hong',
  0x60 => 'tuo', 'diao', 'ji', 'xu', 'e', 'e', 'sha', 'hang', 'tun', 'mo', 'jie', 'shen', 'ban', 'yuan', 'pi', 'lu',
  0x70 => 'wen', 'hu', 'lu', 'za', 'fang', 'fen', 'na', 'you', 'pian', 'mo', 'he', 'xia', 'qu', 'han', 'pi', 'ling',
  0x80 => 'tuo', 'bo', 'qiu', 'ping', 'fu', 'bi', 'ci', 'wei', 'ju', 'diao', 'ba', 'you', 'gun', 'pi', 'nian', 'xing',
  0x90 => 'tai', 'bao', 'fu', 'zha', 'ju', 'gu', 'shi', 'dong', 'dai', 'ta', 'jie', 'shu', 'hou', 'xiang', 'er', 'an',
  0xA0 => 'wei', 'zhao', 'zhu', 'yin', 'lie', 'luo', 'tong', 'ti', 'yi', 'bing', 'wei', 'jiao', 'ku', 'gui', 'xian', 'ge',
  0xB0 => 'hui', 'lao', 'fu', 'kao', 'xiu', 'duo', 'jun', 'ti', 'mian', 'shao', 'zha', 'suo', 'qin', 'yu', 'nei', 'zhe',
  0xC0 => 'gun', 'geng', 'su', 'wu', 'qiu', 'shan', 'pu', 'huan', 'tiao', 'li', 'sha', 'sha', 'kao', 'meng', 'cheng', 'li',
  0xD0 => 'zou', 'xi', 'yong', 'ni', 'zi', 'qi', 'zheng', 'xiang', 'nei', 'chun', 'ji', 'diao', 'qie', 'gu', 'zhou', 'dong',
  0xE0 => 'lai', 'fei', 'ni', 'yi', 'kun', 'lu', 'jiu', 'chang', 'jing', 'lun', 'ling', 'zou', 'li', 'meng', 'zong', 'zhi',
  0xF0 => 'nian', 'hu', 'yu', 'di', 'shi', 'shen', 'hun', 'ti', 'hou', 'xing', 'zhu', 'la', 'zong', 'zei', 'bian', 'bian',
];
